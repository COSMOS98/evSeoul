// gnb
$(document).ready(function(){
    var subBg = $('<div class="subBg"></div>');
    
    $('header').append(subBg);
    
    var gnb = '.gnb';
    var main = '.mainNav';
    var sub = '.subNav';
    var bg = '.subBg';
    var speed = 'fast';

    $(gnb).hover(function(){
        $(sub + ', ' + bg).stop().slideDown(speed);
        $(main).removeClass('active');
    },function(){
        $(sub + ', ' + bg).stop().slideUp(speed);
        $(main).removeClass('active');
    });
    
    $(main).focus(function(){ 
        $(sub + ', ' + bg).stop().slideDown(speed);
        $(this).addClass('active');
    });
    
    $(main).focus(function(){
        $(main).removeClass('active'); 
        $(this).addClass('active'); 
    });
    
    $(main).first().keydown(function(e){
        if(e.keyCode == 9){ 
            if(e.shiftKey){ 
                $(sub + ', ' + bg).stop().slideUp(speed);
                $(this).removeClass('active');
            }
        }
    });
    
    $(sub).last().find('li:last a').keydown(function(e){
        if(e.keyCode == 9){ 
            if(!e.shiftKey){ 
                $(sub + ', ' + bg).stop().slideUp(speed);
                $(main).removeClass('active');
            }
        }
    });
    
    $(sub).find('li:last a').focus(function(){
        $(main).removeClass('active');
        $(this).parents(sub).prev().addClass('active');
    });
    
    $('header').mouseleave(function(){
        $(main).removeClass('active');
        $(sub + ', ' + bg).stop().slideUp(speed);
    });
    
});

