$(document).ready(function() {
	// 페이징 이벤트
	var actionForm = $("#actionForm");
	
	$(".numList").on("click", function(e) {
		e.preventDefault();	
    	e.stopPropagation();
		
		var targetPage = $(this).attr("href");
		
		actionForm.find("input[name='pageNum']").val(targetPage);
		actionForm.submit();
	});
	
	
	$(".move").on("click", function(e) {
		e.preventDefault();	
		
		var targetBno = $(this).attr("href");
		
		actionForm.append("<input type='hidden' name='SEQ' value='"+targetBno+"' />");
		actionForm.attr("action", "/board/get");
		actionForm.submit();
	});
	
	
	// 검색 이벤트
	var searchForm = $("#searchForm");
	
	$("#searchBtn").on("click", function(e) {		
		searchForm.find("input[name='pageNum']").val("1");		
		searchForm.submit();
	});
	
});