package com.evseoul.biz.service;

import java.util.List;

import com.evseoul.biz.mark.MarkVO;

public interface MarkMapper {
	
	public List<MarkVO> getMark(String getMark);
}
