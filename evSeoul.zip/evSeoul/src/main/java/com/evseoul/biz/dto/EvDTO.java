package com.evseoul.biz.dto;

import lombok.Data;

@Data
public class EvDTO {

	private String getMark;


}
