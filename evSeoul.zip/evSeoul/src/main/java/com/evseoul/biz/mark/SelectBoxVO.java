package com.evseoul.biz.mark;

public class SelectBoxVO {
	private String address2;

	public String getAddress2() {
		return address2;
	}

	public void setAddress2(String address2) {
		this.address2 = address2;
	}

}
